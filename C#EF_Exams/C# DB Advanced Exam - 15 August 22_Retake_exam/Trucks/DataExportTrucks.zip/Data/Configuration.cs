﻿namespace Trucks.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}