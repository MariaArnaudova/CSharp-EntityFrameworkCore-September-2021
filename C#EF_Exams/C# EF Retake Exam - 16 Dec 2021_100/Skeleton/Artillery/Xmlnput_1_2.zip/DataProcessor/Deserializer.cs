﻿namespace Artillery.DataProcessor
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.IO;
    using System.Text;
    using System.Xml.Serialization;
    using Artillery.Data;
    using Artillery.Data.Models;
    using Artillery.DataProcessor.ImportDto;



    public class Deserializer
    {
        private const string ErrorMessage =
                "Invalid data.";
        private const string SuccessfulImportCountry =
            "Successfully import {0} with {1} army personnel.";
        private const string SuccessfulImportManufacturer =
            "Successfully import manufacturer {0} founded in {1}.";
        private const string SuccessfulImportShell =
            "Successfully import shell caliber #{0} weight {1} kg.";
        private const string SuccessfulImportGun =
            "Successfully import gun {0} with a total weight of {1} kg. and barrel length of {2} m.";

        public static string ImportCountries(ArtilleryContext context, string xmlString)
        {
            var sb = new StringBuilder();
            var validCounties = new List<Country>();

            //var countries = XmlConverter.Deserializer<CountriesXmlImportModel>(xmlString, "Countries");
            var xmlSerializer = new XmlSerializer(
                typeof(CountriesXmlImportModel[]),
                new XmlRootAttribute("Countries"));
            var countries = (CountriesXmlImportModel[])xmlSerializer.Deserialize(
                new StringReader(xmlString));

            foreach (var currCountry in countries)
            {
                if (!IsValid(currCountry))
                {
                    sb.AppendLine($"Invalid data.");
                    continue;
                }

                Country country = new Country
                {
                    ArmySize = currCountry.ArmySize,
                    CountryName = currCountry.CountryName,
                };

                validCounties.Add(country);
                sb.AppendLine($"Successfully import {country.CountryName} with {country.ArmySize} army personnel.");
            }

            context.Countries.AddRange(validCounties);
            context.SaveChanges();

            return sb.ToString().TrimEnd();   
        }

        public static string ImportManufacturers(ArtilleryContext context, string xmlString)
        {
            var sb = new StringBuilder();
            var validManufacturers = new List<Manufacturer>();

            //var countries = XmlConverter.Deserializer<CountriesXmlImportModel>(xmlString, "Countries");
            var xmlSerializer = new XmlSerializer(
                typeof(ManufacturerXmlImportModel[]),
                new XmlRootAttribute("Manufacturers"));
            var manufacrurers = (ManufacturerXmlImportModel[])xmlSerializer.Deserialize(
                new StringReader(xmlString));

            foreach(var currManufacturers in manufacrurers)
            {
                if (!IsValid(currManufacturers))
                {
                    sb.AppendLine($"Invalid data.");
                    continue;
                }

                if (context.Manufacturers.Any(m => m.ManufacturerName == currManufacturers.ManufacturerName)
                    || validManufacturers.Any(m => m.ManufacturerName == currManufacturers.ManufacturerName))
                {
                    sb.AppendLine($"Invalid data.");
                    continue;
                }

                Manufacturer manufacturer = new Manufacturer
                {
                    Founded = currManufacturers.Founded,
                    ManufacturerName = currManufacturers.ManufacturerName
                };

                //var manNames = String.Join(", ", manufacturer.Founded.Split(", ")
                //    .Where(t => !t.Any(char.IsDigit)));
                var manNames =  manufacturer.Founded.Split(", ")
                 .Where(t => !t.Any(char.IsDigit)).ToArray();

                var country = manNames[manNames.Length - 1];
                var town = manNames[manNames.Length - 2];

                validManufacturers.Add(manufacturer);
                sb.AppendLine($"Successfully import manufacturer {manufacturer.ManufacturerName} founded in {town}, {country}.");
            }

            context.Manufacturers.AddRange(validManufacturers);
            context.SaveChanges();
            return sb.ToString().TrimEnd();   
        }

        public static string ImportShells(ArtilleryContext context, string xmlString)
        {
            throw new NotImplementedException();
        }

        public static string ImportGuns(ArtilleryContext context, string jsonString)
        {
            throw new NotImplementedException();
        }
        private static bool IsValid(object obj)
        {
            var validator = new ValidationContext(obj);
            var validationRes = new List<ValidationResult>();

            var result = Validator.TryValidateObject(obj, validator, validationRes, true);
            return result;
        }
    }
}
