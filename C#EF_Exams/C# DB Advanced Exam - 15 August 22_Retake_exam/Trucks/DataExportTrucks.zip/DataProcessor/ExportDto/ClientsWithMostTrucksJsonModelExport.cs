﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trucks.DataProcessor.ExportDto
{
    public class ClientsWithMostTrucksJsonModelExport
    {
    }
}
